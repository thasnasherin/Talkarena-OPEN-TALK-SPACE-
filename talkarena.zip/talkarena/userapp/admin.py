from django.contrib import admin
from.models import *
# Register your models here.
admin.site.register(regdb)
admin.site.register(contdb)
admin.site.register(psyapn)
admin.site.register(atapn)
admin.site.register(topic)
admin.site.register(reply)