from django.db import models

# Create your models here.

class bldb(models.Model):
    bwrd=models.CharField(max_length=200)
 
 